//
//  otherViewController.h
//  PetroChina.THYT.ERP
//
//  Created by Migoo on 16/5/6.
//  Copyright © 2016年 Migoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface otherViewController : UITableViewController

@end
