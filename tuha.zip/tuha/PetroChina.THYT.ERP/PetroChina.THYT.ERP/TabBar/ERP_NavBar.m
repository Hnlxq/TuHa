//
//  ERP_NavBar.m
//  PetroChina.THYT.ERP
//
//  Created by Migoo on 16/4/28.
//  Copyright © 2016年 Migoo. All rights reserved.
//

#import "ERP_NavBar.h"
#import "AppDelegate.h"







@interface ERP_NavBar ()

@end

@implementation ERP_NavBar

- (void)viewDidLoad {
    [super viewDidLoad];
    //设置渲染颜色
   // self.navigationBar.barTintColor =NavBarColor(204, 0, 0);
    
   
    // Do any additional setup after loading the view.
}
+ (void)initialize
{
    UINavigationBar *bar = [UINavigationBar appearance];
    bar.barTintColor = NavBarColor(201, 27, 0);
   
    
}

/**
 *  重写这个方法目的：能够拦截所有push进来的控制器
 *
 *  @param viewController 即将push进来的控制器
 */


- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    
    /* 设置导航栏上面的内容 */
    // 设置左边的返回按钮
    if (self.viewControllers.count==0) {
        
    UIButton *leftButton=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 27, 27)];
    [leftButton setImage:[UIImage imageNamed:@"zsyou_logo"] forState:UIControlStateNormal];
    [leftButton addTarget:self action:@selector(openOrCloseLeftList) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem * leftItem =[[UIBarButtonItem alloc]initWithCustomView:leftButton];
    viewController.navigationItem.leftBarButtonItem = leftItem;
    
    
    // 设置右边的更多按钮
    UIButton *right = [UIButton buttonWithType:UIButtonTypeCustom];
    right.frame = CGRectMake(0, 0, 60, 27);
    right.titleLabel.font=[UIFont systemFontOfSize:15];
    [right addTarget:self action:@selector(more) forControlEvents:UIControlEventTouchUpInside];
    [right setTitle:@"返回大厅" forState:UIControlStateNormal];
    [right setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    UIBarButtonItem *rightBut = [[UIBarButtonItem alloc]initWithCustomView:right];
    viewController.navigationItem.rightBarButtonItem = rightBut;
    }
    [super pushViewController:viewController animated:animated];
    
}
//- (void)viewWillDisappear:(BOOL)animated
//{
//    [super viewWillDisappear:animated];
//    NSLog(@"viewWillDisappear");
//    AppDelegate *tempAppDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
//    [tempAppDelegate.LeftSlideVC setPanEnabled:NO];
//}
//
//- (void)viewWillAppear:(BOOL)animated
//{
//    [super viewWillAppear:animated];
//    NSLog(@"viewWillAppear");
//    AppDelegate *tempAppDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
//   [tempAppDelegate.LeftSlideVC setPanEnabled:YES];
//}

//打开左边视图
- (void)openOrCloseLeftList
{
    
    AppDelegate *tempAppDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    if (tempAppDelegate.LeftSlideVC.closed)
    {
        [tempAppDelegate.LeftSlideVC openLeftView];
    }
    else
    {
        [tempAppDelegate.LeftSlideVC closeLeftView];
    }

}










- (void)more
{
    
    NSLog(@"sas");
    //[[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"EnterpriseHall://"]]];
    //[self popToRootViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
