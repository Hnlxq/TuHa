//
//  ERP_TabBar.m
//  PetroChina.THYT.ERP
//
//  Created by Migoo on 16/4/28.
//  Copyright © 2016年 Migoo. All rights reserved.
//

#import "ERP_TabBar.h"
#import "ERP_GongYSGLTV.h"
#import "ERP_HeTGLTV.h"
#import "ERP_WuZGLTV.h"
#import "ERP_ZhaoBTBTV.h"
#import "ERP_NavBar.h"
#import "AppDelegate.h"
//#import "YRSideViewController.h"

@interface ERP_TabBar ()

@end

@implementation ERP_TabBar

- (void)viewDidLoad {
    [super viewDidLoad];
   
    //初始化子控制器
    ERP_WuZGLTV *WuZGL = [[ERP_WuZGLTV alloc]init];
    [self addChildVc:WuZGL title:@"物资管理" image:@"WuZGL"];
    ERP_HeTGLTV *HeTGL= [[ERP_HeTGLTV alloc]init];
    [self addChildVc:HeTGL title:@"合同管理" image:@"HeTGL"];
    ERP_ZhaoBTBTV *ZhaoBTB = [[ERP_ZhaoBTBTV alloc]init];
    [self addChildVc:ZhaoBTB title:@"招标投标" image:@"ZhaoBTB"];
    ERP_GongYSGLTV *GongYSGL = [[ERP_GongYSGLTV alloc]init];
    [self addChildVc:GongYSGL title:@"供应商管理" image:@"GongYSGL"];

    
    // Do any additional setup after loading the view.
}
- (void)addChildVc:(UIViewController *)childVc title:(NSString *)title image:(NSString *)image
{
    
    childVc.title = title; // 同时设置tabbar和navigationBar的文字
    //自定义标题
    
    UILabel * titleL = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100, 44)];
    
    titleL.text = title;
    
    titleL.textAlignment = NSTextAlignmentCenter;
    
    titleL.textColor = [UIColor whiteColor];
    // 设置子控制器的标题文字
    childVc.navigationItem.titleView = titleL;
    
    
    
    
    // 设置子控制器的图片
    childVc.tabBarItem.image = [UIImage imageNamed:image];
    
    // childVc.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImage]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    // 设置文字的样式
    NSMutableDictionary *textAttrs = [NSMutableDictionary dictionary];
    textAttrs[NSForegroundColorAttributeName] = LXColor(123, 123, 123);
    NSMutableDictionary *selectTextAttrs = [NSMutableDictionary dictionary];
    selectTextAttrs[NSForegroundColorAttributeName] = NavBarColor(204, 0, 0);
    
    
    [childVc.tabBarItem setTitleTextAttributes:textAttrs forState:UIControlStateNormal];
    [childVc.tabBarItem setTitleTextAttributes:selectTextAttrs forState:UIControlStateSelected];
    
    // 先给外面传进来的小控制器 包装 一个导航控制器
    ERP_NavBar *nav = [[ERP_NavBar alloc] initWithRootViewController:childVc];
    
    
    nav.tabBarItem.title = title;
    
    // 添加为子控制器
    [self addChildViewController:nav];
    
}

//- (void)viewWillDisappear:(BOOL)animated
//{
//    [super viewWillDisappear:animated];
//    NSLog(@"viewWillDisappear");
//    AppDelegate *tempAppDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
//    [tempAppDelegate.LeftSlideVC setPanEnabled:NO];
//}
//
//- (void)viewWillAppear:(BOOL)animated
//{
//    [super viewWillAppear:animated];
//    NSLog(@"viewWillAppear");
//    AppDelegate *tempAppDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
//    [tempAppDelegate.LeftSlideVC setPanEnabled:YES];
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
