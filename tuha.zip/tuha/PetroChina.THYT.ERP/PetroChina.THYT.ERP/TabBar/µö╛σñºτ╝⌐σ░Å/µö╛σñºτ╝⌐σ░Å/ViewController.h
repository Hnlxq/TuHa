//
//  ViewController.h
//  放大缩小
//
//  Created by Migoo on 16/5/9.
//  Copyright © 2016年 Migoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

