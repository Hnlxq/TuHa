//
//  ERP_DetailWuZGL.h
//  PetroChina.THYT.ERP
//
//  Created by Migoo on 16/5/6.
//  Copyright © 2016年 Migoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ERP_DetailWuZGL : UITableViewController

@end
