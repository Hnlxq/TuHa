//
//  ERP.h
//  PetroChina.THYT.ERP
//
//  Created by Migoo on 16/4/29.
//  Copyright © 2016年 Migoo. All rights reserved.
//

#ifndef ERP_h
#define ERP_h

typedef enum :NSInteger{
    Enum_One,
    Enum_Two
    
}RankListType;

#endif /* ERP_h */
