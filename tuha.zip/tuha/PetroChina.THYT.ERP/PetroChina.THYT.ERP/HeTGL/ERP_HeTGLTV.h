//
//  ERP_HeTGLTV.h
//  PetroChina.THYT.ERP
//
//  Created by Migoo on 16/4/29.
//  Copyright © 2016年 Migoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ERP_HeTGLTV : UIViewController

@end
