//
//  ERP_HeTGLDetail.h
//  PetroChina.THYT.ERP
//
//  Created by Migoo on 16/4/29.
//  Copyright © 2016年 Migoo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ERP.h"
@interface ERP_HeTGLDetail : UITableViewController
@property(nonatomic,assign)RankListType rankType;

@end
