//
//  ERP_HeTGLTV.m
//  PetroChina.THYT.ERP
//
//  Created by Migoo on 16/4/29.
//  Copyright © 2016年 Migoo. All rights reserved.
//

#import "ERP_HeTGLTV.h"
#import "ERP_HeTGLDetail.h"

@interface ERP_HeTGLTV ()<UIScrollViewDelegate>{
    UISegmentedControl * sgc;
    
    UIScrollView * _scrollView;
}

@end

@implementation ERP_HeTGLTV

- (void)viewDidLoad {
    [super viewDidLoad];
    if([UIDevice currentDevice].systemVersion.floatValue >= 7.0){
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    [self creatUI];
    // Do any additional setup after loading the view.
}

-(void)creatUI{
    sgc= [[UISegmentedControl alloc] initWithItems:@[@"周排行榜",@"月排行榜"]];
    sgc.selectedSegmentIndex=0;
    [sgc addTarget:self action:@selector(sgementAction:) forControlEvents:UIControlEventValueChanged];
    [self.navigationController.navigationBar setTintColor:[UIColor whiteColor]];
    self.navigationItem.titleView=sgc;
    
    _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH,SCREEN_HEIGHT)];
    _scrollView.pagingEnabled=YES;
    _scrollView.showsHorizontalScrollIndicator=NO;
    _scrollView.showsVerticalScrollIndicator=NO;
    _scrollView.bounces=NO;
    _scrollView.delegate =self;
    _scrollView.contentSize = CGSizeMake(SCREEN_WIDTH*2, SCREEN_HEIGHT) ;
    [self.view addSubview:_scrollView];
    [self addSubControllers];
    
    
}
-(void)addSubControllers{
    for (NSInteger  i=0 ; i<2; i++) {
        ERP_HeTGLDetail * list = [[ERP_HeTGLDetail alloc] init];
        if (i==0) {
            list.rankType=Enum_One;
        }else if (i==1){
            list.rankType=Enum_Two;
            
        }
        list.view.frame = CGRectMake(i*SCREEN_WIDTH, 0, SCREEN_WIDTH, SCREEN_HEIGHT-113);
       
        list.view.backgroundColor=[UIColor blueColor];
        [self addChildViewController:list];
        [_scrollView addSubview:list.view];
        
    }
}
-(void)sgementAction:(UISegmentedControl *)sg{
    [UIView animateWithDuration:0.5f animations:^{
        _scrollView.contentOffset =CGPointMake(sg.selectedSegmentIndex*SCREEN_WIDTH, 0);
    }];
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    
    NSInteger index=scrollView.contentOffset.x/SCREEN_WIDTH;
    sgc.selectedSegmentIndex=index;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
