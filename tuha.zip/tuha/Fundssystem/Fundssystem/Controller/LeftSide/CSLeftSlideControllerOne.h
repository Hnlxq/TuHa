//
//  ViewController.h
//  CSLeftSlideDemo
//
//  Created by LCS on 16/2/11.
//  Copyright © 2016年 LCS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CSLeftSlideControllerOne : UIViewController

- (id)initWithLeftViewController:(UIViewController *)leftVC MainViewController:(UIViewController *)mainVC;
@end

