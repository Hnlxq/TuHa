//
//  OtherViewController.h
//  CSLeftSlideDemo
//
//  Created by LCS on 16/2/12.
//  Copyright © 2016年 LCS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OtherViewController : UIViewController

@end
