//
//  OtherViewController.m
//  CSLeftSlideDemo
//
//  Created by LCS on 16/2/12.
//  Copyright © 2016年 LCS. All rights reserved.
//

#import "OtherViewController.h"

@interface OtherViewController ()

@end

@implementation OtherViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"其他界面";
    self.view.backgroundColor = [UIColor whiteColor];
}

@end
