//
//  AppDelegate.h
//  PetroChina.THYT.ZongHBG
//
//  Created by Migoo on 16/4/5.
//  Copyright © 2016年 Migoo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftSlideViewController.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>
{

    NSString *Jurisdiction;

}

@property (strong, nonatomic) UIWindow *window;
@property(strong,nonatomic)NSString *Jurisdiction;
@property (strong, nonatomic) LeftSlideViewController *LeftSlideVC;

@end

