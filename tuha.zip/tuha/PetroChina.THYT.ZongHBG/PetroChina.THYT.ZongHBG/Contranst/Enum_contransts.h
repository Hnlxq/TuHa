//
//  Enum_contransts.h
//  PetroChina.THYT.ZongHBG
//
//  Created by Migoo on 16/4/27.
//  Copyright © 2016年 Migoo. All rights reserved.
//

#ifndef Enum_contransts_h
#define Enum_contransts_h

typedef enum {
    Enum_WeekList=100,
    Enum_MonthLiat
 
}RankListType;

#endif /* Enum_contransts_h */
