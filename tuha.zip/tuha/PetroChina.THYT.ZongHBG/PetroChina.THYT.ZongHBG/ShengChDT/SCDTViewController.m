//
//  SCDTViewController.m
//  PetroChina.THYT.ZongHBG
//
//  Created by Migoo on 16/4/27.
//  Copyright © 2016年 Migoo. All rights reserved.
//

#import "SCDTViewController.h"

@interface SCDTViewController ()
@property(nonatomic,strong)UIWebView *webView;

@end

@implementation SCDTViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self startWebview];
    // Do any additional setup after loading the view.
}
//开始网络请求
- (void)startWebview{
    NSString * url ;
    if (self.rankType==Enum_WeekList) {
        url=@"https://www.baidu.com";
    }
    if (self.rankType==Enum_MonthLiat) {
    url=@"http://www.cn.bing.com";
    }
    self.webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-113)];
    self.webView.scalesPageToFit =YES;
    
    
    
    self.webView.delegate=self;
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    [self.webView loadRequest:request];
    
    [self.view addSubview:self.webView];
}






- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
