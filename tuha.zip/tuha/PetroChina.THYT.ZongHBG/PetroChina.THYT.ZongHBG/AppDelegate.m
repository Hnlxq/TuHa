//
//  AppDelegate.m
//  PetroChina.THYT.ZongHBG
//
//  Created by Migoo on 16/4/5.
//  Copyright © 2016年 Migoo. All rights reserved.
//

#import "AppDelegate.h"
#import "MyTabBarViewController.h"
#import "LeftSortsViewController.h"




@interface AppDelegate ()<NSXMLParserDelegate,UIAlertViewDelegate>

@property(nonatomic,strong)NSMutableString *currentName;
@property(nonatomic,strong)NSString *LoginID;


@end

@implementation AppDelegate

@synthesize Jurisdiction = Jurisdiction;




-(BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
    if (url==0)
    {
//        UIAlertView *alertview = [[UIAlertView alloc] initWithTitle:@"标题" message:@"这个是UIAlertView的默认样式" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"好的", nil];
//        [alertview show];
        return NO;
    }else{
    
       // self.LoginID = [BSMCPBaseUtils getParams:@"LoginID" fromeURLParams:url.absoluteString];
        
//        
//        UIAlertView *alertview = [[UIAlertView alloc] initWithTitle:self.LoginID message:url.absoluteString delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
//        [alertview show];
     //  [self getJurisdiction];
        
        return YES;
    }
    
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    //[WNXTopWindow show];
//    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
//    // Override point for customization after application launch.
//    self.window.backgroundColor = [UIColor whiteColor];
//    [self.window makeKeyAndVisible];
//
//    
//    //创建标签视图控制器对象
//    MyTabBarViewController *myTabbarV = [[MyTabBarViewController alloc]init];
//    
//    //3讲tabBarV指定为跟视图控制器
//    self.window.rootViewController=myTabbarV;
//    //[WNXTopWindow show];
//    return YES;
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor whiteColor];   //设置通用背景颜色
    [self.window makeKeyAndVisible];
    
    MyTabBarViewController *mainVC = [[MyTabBarViewController alloc] init];
    //self.mainNavigationController = [[UINavigationController alloc] initWithRootViewController:mainVC];
    LeftSortsViewController *leftVC = [[LeftSortsViewController alloc] init];
    //UINavigationController *nav=[[UINavigationController alloc]initWithRootViewController:leftVC];
    self.LeftSlideVC = [[LeftSlideViewController alloc] initWithLeftView:leftVC andMainView:mainVC];
    self.window.rootViewController = self.LeftSlideVC;
    // [NSThread sleepForTimeInterval:3.0];
    
    
    
    // Override point for customization after application launch.
    return YES;

}

- (void)getJurisdiction
{
// NSString *name = self.LoginID;
    NSString *code = @"10";
    NSString *module =[NSString stringWithFormat:@"业务动态"];
//    
    
    NSString *soapStr =[NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://service.authentication.petrochina.com/\"><soapenv:Header/><soapenv:Body><ser:getLeavesByUserIdAndAppIdAndLeafId><!--Optional:--><arg0>\(%@)</arg0><!--Optional:--><arg1>\(%@)</arg1><!--Optional:--><arg2>\(%@)</arg2></ser:getLeavesByUserIdAndAppIdAndLeafId></soapenv:Body></soapenv:Envelope>",self.LoginID,code,module];
    //1构造URL

    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://127.0.0.1:10034/tuhaauthenticservice/IAuthenticImplPort"]];
    //2构造request
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    
    [request addValue:[NSString stringWithFormat:@"http://127.0.0.1:10034/tuhaauthenticservice/IAuthenticImplPort"] forHTTPHeaderField:@"SOAPAction"];
    [request addValue:[NSString stringWithFormat:@"%d",[soapStr length]] forHTTPHeaderField:@"Content-Length"];
    
    
    //（1）设置为post请求
    [request setHTTPMethod:@"POST"];
      //（2）超时
    [request setTimeoutInterval:10.0];
      //（3）设置请求头
    //[request setAllHTTPHeaderFields:nil];
      // (4)设置请求体
    NSData *bodyData = [soapStr dataUsingEncoding:NSUTF8StringEncoding];
    [request setHTTPBody:bodyData];
    //3  发送同步请求, data就是返回的数据
    
    
//     NSError *error = nil;
//     NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:&error];


    
    //3构造Session
    
    NSURLSession *session = [NSURLSession sharedSession];
    //4.task
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
//
  
        NSXMLParser *parser = [[NSXMLParser alloc]initWithData:data];
        NSString *str = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
//        
    UIAlertView *alertview = [[UIAlertView alloc] initWithTitle:str message:@"haode" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertview show];
    
        //未插加密机或加密机信息读取失败
        if (self.LoginID==nil) {
            UIAlertView *alertview = [[UIAlertView alloc] initWithTitle:@"加密机信息读取异常" message:@"如有疑问请与系统管理员联系!" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alertview show];
//            UIAlertController *alter = [UIAlertController alertControllerWithTitle:@"加密机信息读取异常" message:@"如有疑问请与系统管理员联系!" preferredStyle:UIAlertControllerStyleAlert];
//            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
//                
//            }];
//            [alter addAction:cancelAction];
//            return ;
            
            
        }
        //服务器验证地址访问异常
        if (data == nil) {
            UIAlertView *altView=[[UIAlertView alloc]initWithTitle:@"服务器信息连接异常" message:@"如有疑问请与系统管理员联系!" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [altView show];
            
        }
        [parser setDelegate:self];
        [parser parse];

   
        }];
    
    //5.
    [task resume];

}

//第一个代理方法
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary<NSString *,NSString *> *)attributeDict
{
    

}
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    [self.currentName appendString:string];
   

}
//从权限验证服务器返回验证结果

- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    NSData *jsonData=[NSJSONSerialization dataWithJSONObject:self.currentName options:NSJSONWritingPrettyPrinted error:nil];
   NSString *isJurisdiction = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
    NSString *str = @"\"returnCode\":561";
    if ([isJurisdiction rangeOfString:str].location != NSNotFound) {
        
        UIAlertController *alter = [UIAlertController alertControllerWithTitle:@"对不起您没有权限使用该系统" message:@"如有疑问请与系统管理员联系!" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        [alter addAction:cancelAction];
        return ;
    }else{

        self.Jurisdiction = self.currentName;
    
    }
}


- (BOOL)application:(UIApplication *)application willFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    NSDictionary *launchData = launchOptions;
    if (launchData == nil) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"EnterpriseHall://"]]];
        
        return NO;
        
    }else{
    
        return YES;
    }

   
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex==0) {
        
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"EnterpriseHall://"]]];
    }

}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
