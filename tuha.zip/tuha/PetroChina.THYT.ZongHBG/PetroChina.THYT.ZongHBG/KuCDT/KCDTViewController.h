//
//  KCDTViewController.h
//  PetroChina.THYT.ZongHBG
//
//  Created by Migoo on 16/4/27.
//  Copyright © 2016年 Migoo. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface KCDTViewController : UIViewController<UIWebViewDelegate>
@property(nonatomic,assign)RankListType rankType;

@end
