//
//  ZongHBG_KuCDTViewController.m
//  PetroChina.THYT.ZongHBG
//
//  Created by Migoo on 16/4/5.
//  Copyright © 2016年 Migoo. All rights reserved.
//

#import "ZongHBG_KuCDTViewController.h"
#import "KCDTViewController.h"

#define First   @"http://127.0.0.1:10034/DayReport1/cyc_rb/openFlashChart/dynamic/kcdtsy.jsp"
#define Second  @"http://127.0.0.1:10034/DayReport1/cyc_rb/openFlashChart/dynamic/kcdt.jsp"

@interface ZongHBG_KuCDTViewController ()<UIScrollViewDelegate>{
    UISegmentedControl * sgc;
    
    UIScrollView * _scrollView;
}
@end

@implementation ZongHBG_KuCDTViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tabBarController.tabBar.tintColor= [UIColor redColor];
   
    if([UIDevice currentDevice].systemVersion.floatValue >= 7.0){
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    [self creatUI];
    
    
}
//创建ui
-(void)creatUI{
    sgc= [[UISegmentedControl alloc] initWithItems:@[@"库存动态",@"详细查询"]];
    sgc.selectedSegmentIndex=0;
    [sgc addTarget:self action:@selector(sgementAction:) forControlEvents:UIControlEventValueChanged];
    [self.navigationController.navigationBar setTintColor:[UIColor whiteColor]];
    self.navigationItem.titleView=sgc;
    
    _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH,SCREEN_HEIGHT)];
    _scrollView.pagingEnabled=YES;
    _scrollView.showsHorizontalScrollIndicator=NO;
    _scrollView.showsVerticalScrollIndicator=NO;
    _scrollView.bounces=NO;
    _scrollView.delegate =self;
    _scrollView.contentSize = CGSizeMake(SCREEN_WIDTH*2, SCREEN_HEIGHT) ;
    [self.view addSubview:_scrollView];
    [self addSubControllers];
    
    
}
-(void)addSubControllers{
    for (NSInteger  i=0 ; i<2; i++) {
        KCDTViewController * list = [[KCDTViewController alloc] init];
        if (i==0) {
            list.rankType=Enum_WeekList;
        }else if (i==1){
            list.rankType=Enum_MonthLiat;
            
        }
        list.view.frame = CGRectMake(i*SCREEN_WIDTH, 0, SCREEN_WIDTH, SCREEN_HEIGHT-113);
        [self addChildViewController:list];
        [_scrollView addSubview:list.view];
        
    }
}
-(void)sgementAction:(UISegmentedControl *)sg{
    [UIView animateWithDuration:0.5f animations:^{
        _scrollView.contentOffset =CGPointMake(sg.selectedSegmentIndex*SCREEN_WIDTH, 0);
    }];
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    
    NSInteger index=scrollView.contentOffset.x/SCREEN_WIDTH;
    sgc.selectedSegmentIndex=index;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
