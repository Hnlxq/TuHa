//
//  XSDTViewController.h
//  PetroChina.THYT.ZongHBG
//
//  Created by Migoo on 16/5/6.
//  Copyright © 2016年 Migoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XSDTViewController : UIViewController<UIWebViewDelegate>
@property(nonatomic,assign)RankListType rankType;

@end
