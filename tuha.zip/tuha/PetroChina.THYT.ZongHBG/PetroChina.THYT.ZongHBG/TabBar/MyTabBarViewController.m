//
//  MyTabBarViewController.m
//  PetroChina.THYT.ZongHBG
//
//  Created by Migoo on 16/4/5.
//  Copyright © 2016年 Migoo. All rights reserved.
//

#import "MyTabBarViewController.h"
#import "ZongHBG_KaiFDTViewController.h"
#import "ZongHBG_KanTDTViewController.h"
#import "ZongHBG_KuCDTViewController.h"
#import "ZongHBG_ShengChDTViewController.h"
#import "ZongHBG_XiaoShDTViewController.h"
#import "MyNavigationViewController.h"

@interface MyTabBarViewController ()

@end

@implementation MyTabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //初始化子控制器
    ZongHBG_ShengChDTViewController *shengVc=[[ZongHBG_ShengChDTViewController alloc]init];
    [self addChildVc:shengVc title:@"生产动态" image:@"ShengChDT" ];
    
    ZongHBG_KanTDTViewController *kanVc = [[ZongHBG_KanTDTViewController alloc]init];
    [self addChildVc:kanVc title:@"勘测动态" image:@"KanTDT" ];
    ZongHBG_KaiFDTViewController * kaiVc = [[ZongHBG_KaiFDTViewController alloc]init];
    [self addChildVc:kaiVc title:@"开发动态" image:@"KaiFDT" ];
    ZongHBG_KuCDTViewController *kuVc=[[ZongHBG_KuCDTViewController alloc]init];
    [self addChildVc:kuVc title:@"库存动态" image:@"KuCDT" ];
    
    ZongHBG_XiaoShDTViewController *xiaoVc = [[ZongHBG_XiaoShDTViewController alloc]init];
    [self addChildVc:xiaoVc title:@"销售动态" image:@"XiaoShDT"];
   //self.tabBarController.tabBar.selectedImageTintColor = [UIColor redColor];
    //self.tabBarController.tabBar.tintColor=[UIColor redColor];
    
}
- (void)addChildVc:(UIViewController *)childVc title:(NSString *)title image:(NSString *)image
{
    
//    //自定义标题
// 
//    UILabel * titleL = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100, 44)];
//    
//    titleL.text = title;
//    
//    titleL.textAlignment = NSTextAlignmentCenter;
//    
//    titleL.textColor = [UIColor whiteColor];
//    // 设置子控制器的标题文字
//    childVc.navigationItem.titleView = titleL;
    
    
    childVc.title = title; // 同时设置tabbar和navigationBar的文字
    
    // 设置子控制器的图片
    childVc.tabBarItem.image = [UIImage imageNamed:image];
    
   // childVc.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImage]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    // 设置文字的样式
    NSMutableDictionary *textAttrs = [NSMutableDictionary dictionary];
    textAttrs[NSForegroundColorAttributeName] = LXColor(123, 123, 123);
    NSMutableDictionary *selectTextAttrs = [NSMutableDictionary dictionary];
    selectTextAttrs[NSForegroundColorAttributeName] = NavBarColor(201, 27, 0);
   
    
    [childVc.tabBarItem setTitleTextAttributes:textAttrs forState:UIControlStateNormal];
    [childVc.tabBarItem setTitleTextAttributes:selectTextAttrs forState:UIControlStateSelected];
    
    // 先给外面传进来的小控制器 包装 一个导航控制器
    MyNavigationViewController *nav = [[MyNavigationViewController alloc] initWithRootViewController:childVc];
   // nav.tabBarItem.title = title;
    
    // 添加为子控制器
    [self addChildViewController:nav];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
