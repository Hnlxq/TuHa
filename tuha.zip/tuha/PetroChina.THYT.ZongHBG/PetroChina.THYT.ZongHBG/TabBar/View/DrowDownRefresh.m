//
//  DrowDownRefresh.m
//  PetroChina.THYT.ZongHBG
//
//  Created by Migoo on 16/4/15.
//  Copyright © 2016年 Migoo. All rights reserved.
//

#import "DrowDownRefresh.h"

@interface DrowDownRefresh ()
@property(nonatomic,assign)BOOL isHidden;
@end

@implementation DrowDownRefresh

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        UIView *myView = [[UIView alloc]initWithFrame:CGRectMake(-58, -30, 120, 90)];
        [self addSubview:myView];
        myView.backgroundColor = [UIColor blackColor];
        myView.alpha = 0.4;
        myView.layer.cornerRadius = 8;
        myView.layer.masksToBounds =YES;
        //myView.layer.borderWidth = 1.0;
        UIActivityIndicatorView *activityIndicatorView = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        
        activityIndicatorView.center = CGPointMake(0, 0);
        
        UILabel *myLabel = [[UILabel alloc]initWithFrame:CGRectMake(-48, 20, 100, 30)];
        
        myLabel.font = [UIFont systemFontOfSize:15];
        myLabel.text = @"正在加载";
        myLabel.textAlignment = NSTextAlignmentCenter;
        myLabel.textColor = [UIColor whiteColor];
        [self addSubview:myLabel];
        activityIndicatorView.color=[UIColor whiteColor];
        activityIndicatorView.hidesWhenStopped = YES;
        [activityIndicatorView startAnimating];
        self.hidden = self.isHidden;
    
        
    }
    return self;
}

- (void)setHidden:(BOOL )hidden
{
    self.isHidden = hidden;

}



@end
